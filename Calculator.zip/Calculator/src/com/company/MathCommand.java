package com.company;

public enum MathCommand {
    Add,
    Subtract,
    Multiply,
    Divide
}
